import { NextResponse } from "next/server";
import { z } from "zod";
import { requireArchitectApi } from "@/lib/architect";
import { createArticle } from "@/lib/articles";

const articleSchema = z.object({
  streamId: z.string().trim().min(2).max(24),
  slug: z.string().trim().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/).max(120),
  title: z.string().trim().min(3).max(180),
  subtitle: z.string().trim().max(260),
  excerpt: z.string().trim().min(10).max(600),
  body: z.string().trim().min(20).max(100000),
  category: z.string().trim().min(2).max(80),
  concepts: z.array(z.string().trim().min(1).max(50)).max(12),
  status: z.enum(["draft", "published"]),
  featured: z.boolean(),
});

export async function POST(request: Request) {
  const auth = await requireArchitectApi();
  if (!auth.ok) return NextResponse.json({ error: auth.message }, { status: auth.status });
  try {
    const input = articleSchema.parse(await request.json());
    const article = await createArticle(input);
    return NextResponse.json({ article }, { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) return NextResponse.json({ error: error.issues[0]?.message ?? "Invalid article." }, { status: 400 });
    const message = error instanceof Error && /UNIQUE/i.test(error.message) ? "That stream ID or slug already exists." : "The transmission could not be saved.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
