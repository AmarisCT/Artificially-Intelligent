"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  ArrowLeft, ArrowUpRight, Binary, BookOpen, Boxes, Braces,
  CircleDot, FlaskConical, Network, Search, Shuffle, Sparkles,
} from "lucide-react";
import type { Article } from "@/lib/article-types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const views = [
  { value: "stream", label: "Stream", icon: Binary },
  { value: "map", label: "Map", icon: Network },
  { value: "index", label: "Index", icon: Braces },
  { value: "archive", label: "Archive", icon: Boxes },
  { value: "lab", label: "Lab", icon: FlaskConical },
];

function formatDate(value: string | null) {
  if (!value) return "Unscheduled";
  return new Intl.DateTimeFormat("en", { month: "short", day: "2-digit", year: "numeric" }).format(new Date(value));
}

export function DataStream({ articles }: { articles: Article[] }) {
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<Article | null>(null);
  const [activeConcept, setActiveConcept] = useState<string | null>(null);
  const [labStep, setLabStep] = useState(0);
  const [labScore, setLabScore] = useState(0);

  const concepts = useMemo(() => {
    const map = new Map<string, number>();
    articles.forEach((article) => article.concepts.forEach((concept) => map.set(concept, (map.get(concept) ?? 0) + 1)));
    return [...map.entries()].sort((a, b) => b[1] - a[1]);
  }, [articles]);

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return articles.filter((article) => {
      const matchesQuery = !needle || [article.title, article.excerpt, article.category, ...article.concepts].join(" ").toLowerCase().includes(needle);
      const matchesConcept = !activeConcept || article.concepts.includes(activeConcept);
      return matchesQuery && matchesConcept;
    });
  }, [articles, query, activeConcept]);

  const connectionCount = concepts.reduce((sum, [, count]) => sum + count, 0);
  const labQuestions = [
    "Would you still choose it if nobody could see it?",
    "Did you search for it before it appeared in your feed?",
    "Would you explore the opposite recommendation?",
  ];

  function answerLab(independent: boolean) {
    if (independent) setLabScore((score) => score + 1);
    setLabStep((step) => step + 1);
  }

  useEffect(() => {
    type WebMcpContext = { registerTool?: (tool: Record<string, unknown>, options?: { signal?: AbortSignal }) => void | Promise<void> };
    const context = (document as Document & { modelContext?: WebMcpContext }).modelContext;
    if (!context?.registerTool) return;
    const lifecycle = new AbortController();
    void Promise.resolve(context.registerTool({
      name: "search_data_stream",
      title: "Search the Data Stream",
      description: "Search published Artificially Intelligent transmissions by title, category, excerpt, or concept and update the visible archive results.",
      inputSchema: {
        type: "object",
        properties: { query: { type: "string", minLength: 1, maxLength: 120 } },
        required: ["query"],
        additionalProperties: false,
      },
      annotations: { readOnlyHint: true, untrustedContentHint: false },
      execute(input: unknown) {
        const value = typeof input === "object" && input !== null && "query" in input ? String((input as { query: unknown }).query).trim() : "";
        if (!value) throw new Error("A non-empty search query is required.");
        setQuery(value);
        const matches = articles.filter((article) => [article.title, article.excerpt, article.category, ...article.concepts].join(" ").toLowerCase().includes(value.toLowerCase()));
        return { query: value, matchCount: matches.length, transmissions: matches.slice(0, 10).map((article) => ({ streamId: article.streamId, title: article.title })) };
      },
    }, { signal: lifecycle.signal })).catch(() => undefined);
    return () => lifecycle.abort();
  }, [articles]);

  return (
    <main className="system-shell min-h-screen">
      <header className="sticky top-0 z-30 border-b border-white/15 bg-[#090b0bee] px-4 backdrop-blur-xl sm:px-7">
        <div className="mx-auto flex h-16 max-w-[1600px] items-center gap-4">
          <Link href="/" aria-label="Back to entry" className="grid size-9 place-items-center border border-white/15 text-white/55 transition hover:border-white/35 hover:text-white">
            <ArrowLeft className="size-4" />
          </Link>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold uppercase tracking-[0.18em]">Artificially Intelligent</p>
            <p className="micro-label mt-0.5">The Data Stream</p>
          </div>
          <div className="hidden items-center gap-2 text-xs uppercase tracking-[0.14em] text-white/45 sm:flex"><i className="status-dot" /> Live archive</div>
        </div>
      </header>

      <div className="mx-auto max-w-[1600px] px-4 py-6 sm:px-7 sm:py-8">
        <section className="mb-7 grid gap-px border border-white/15 bg-white/15 sm:grid-cols-3">
          {[
            ["Transmissions", String(articles.length).padStart(2, "0")],
            ["Concepts", String(concepts.length).padStart(2, "0")],
            ["Connections", String(connectionCount).padStart(3, "0")],
          ].map(([label, value]) => (
            <div key={label} className="bg-[#0d1010] px-5 py-4">
              <p className="micro-label">{label}</p><p className="mt-2 font-mono text-2xl text-[#b9ffde]">{value}</p>
            </div>
          ))}
        </section>

        <Tabs defaultValue="stream" className="gap-6">
          <div className="flex flex-col gap-4 border-b border-white/15 pb-5 xl:flex-row xl:items-center xl:justify-between">
            <TabsList variant="line" className="scrollbar-none max-w-full justify-start overflow-x-auto p-0">
              {views.map(({ value, label, icon: Icon }) => (
                <TabsTrigger key={value} value={value} className="min-w-max px-3 py-2 text-xs uppercase tracking-[0.13em]"><Icon /> {label}</TabsTrigger>
              ))}
            </TabsList>
            <div className="relative w-full xl:w-80">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-white/40" />
              <Input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search the archive" className="h-10 rounded-none border-white/20 bg-white/[0.03] pl-10" />
            </div>
          </div>

          <TabsContent value="stream" className="space-y-6">
            <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
              <div><p className="micro-label">Current signal</p><h1 className="display-title mt-2 max-w-3xl text-4xl leading-none sm:text-6xl">Human identity in the age of machine intelligence.</h1></div>
              <Button variant="outline" className="rounded-none border-white/20 bg-transparent" onClick={() => setSelected(articles[Math.floor(Math.random() * articles.length)])}><Shuffle /> Random signal</Button>
            </div>
            {activeConcept && (
              <div className="flex items-center justify-between border border-[#b9ffde55] bg-[#b9ffde0b] px-4 py-3 text-sm">
                <span>Filtering by <strong>{activeConcept}</strong></span><button onClick={() => setActiveConcept(null)} className="text-[#b9ffde] underline underline-offset-4">Clear</button>
              </div>
            )}
            <div className="grid gap-4 lg:grid-cols-2">
              {filtered.map((article, index) => (
                <button key={article.id} onClick={() => setSelected(article)} className={`signal-card group min-h-[330px] p-6 text-left sm:p-8 ${index === 0 && !query && !activeConcept ? "lg:col-span-2 lg:grid lg:grid-cols-[.42fr_1fr] lg:gap-12" : ""}`}>
                  <div className="mb-12 flex items-start justify-between lg:mb-0">
                    <div><p className="font-mono text-xs tracking-[0.16em] text-[#b9ffde]">{article.streamId}</p><p className="mt-2 text-xs uppercase tracking-[0.14em] text-white/40">{formatDate(article.publishedAt)}</p></div>
                    <ArrowUpRight className="size-5 text-white/35 transition group-hover:text-[#b9ffde]" />
                  </div>
                  <div className="self-end">
                    <p className="micro-label mb-3">{article.category}</p>
                    <h2 className="display-title text-4xl leading-[.95] sm:text-5xl">{article.title}</h2>
                    <p className="mt-5 max-w-2xl text-base leading-7 text-white/60">{article.excerpt}</p>
                    <div className="mt-6 flex flex-wrap gap-2">{article.concepts.map((concept) => <span key={concept} className="border border-white/15 px-2 py-1 font-mono text-[.68rem] uppercase tracking-wider text-white/45">{concept}</span>)}</div>
                  </div>
                </button>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="map">
            <div className="system-panel scanline min-h-[620px] overflow-hidden p-5 sm:p-10">
              <div className="flex items-center justify-between"><div><p className="micro-label">Signal map</p><h2 className="mt-2 text-2xl">Select a concept to trace its transmissions.</h2></div><CircleDot className="hidden size-5 text-[#b9ffde] sm:block" /></div>
              <div className="mt-14 grid place-items-center gap-10 sm:grid-cols-2 lg:grid-cols-4">
                {concepts.map(([concept, count], index) => (
                  <button key={concept} onClick={() => setActiveConcept(concept)} className={`concept-node group grid aspect-square place-items-center rounded-full text-center transition hover:border-[#b9ffde] hover:bg-[#b9ffde0d] ${index % 3 === 0 ? "w-40" : index % 3 === 1 ? "w-32" : "w-28"}`}>
                    <span><strong className="block text-sm uppercase tracking-[.14em]">{concept}</strong><small className="mt-2 block font-mono text-[#b9ffde]">{count} signal{count === 1 ? "" : "s"}</small></span>
                  </button>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="index">
            <div className="grid gap-8 lg:grid-cols-[.45fr_1fr]">
              <div><p className="micro-label">Artificially Intelligent Index</p><h2 className="display-title mt-4 text-5xl leading-none">A vocabulary for the human–machine boundary.</h2></div>
              <div className="divide-y divide-white/15 border-y border-white/15">
                {concepts.map(([concept, count]) => (
                  <button key={concept} onClick={() => setActiveConcept(concept)} className="group grid w-full grid-cols-[3rem_1fr_auto] items-center gap-3 py-5 text-left">
                    <span className="font-mono text-xs text-[#b9ffde]">{concept.charAt(0)}</span><span className="text-xl transition group-hover:translate-x-2">{concept}</span><span className="micro-label">{count} linked</span>
                  </button>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="archive">
            <div className="system-panel overflow-hidden">
              <div className="grid grid-cols-[5.5rem_1fr_auto] border-b border-white/15 px-4 py-3 sm:grid-cols-[7rem_1fr_12rem_8rem]"><span className="micro-label">ID</span><span className="micro-label">Transmission</span><span className="micro-label hidden sm:block">Category</span><span className="micro-label">Date</span></div>
              {filtered.map((article) => (
                <button key={article.id} onClick={() => setSelected(article)} className="grid w-full grid-cols-[5.5rem_1fr_auto] items-center border-b border-white/10 px-4 py-5 text-left transition last:border-b-0 hover:bg-white/[0.04] sm:grid-cols-[7rem_1fr_12rem_8rem]">
                  <span className="font-mono text-xs text-[#b9ffde]">{article.streamId}</span><span className="pr-4 text-sm font-medium sm:text-base">{article.title}</span><span className="hidden text-sm text-white/40 sm:block">{article.category}</span><span className="font-mono text-xs text-white/40">{formatDate(article.publishedAt)}</span>
                </button>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="lab">
            <div className="grid gap-5 lg:grid-cols-[1.15fr_.85fr]">
              <div className="system-panel min-h-[470px] p-6 sm:p-9">
                <div className="flex items-center justify-between"><span className="micro-label">Experiment 001</span><Sparkles className="size-5 text-[#b9ffde]" /></div>
                <h2 className="display-title mt-10 text-5xl leading-none">Who are you without the algorithm?</h2>
                {labStep < labQuestions.length ? (
                  <div className="mt-12"><p className="micro-label">Question {labStep + 1} / {labQuestions.length}</p><p className="mt-4 max-w-xl text-2xl leading-snug">{labQuestions[labStep]}</p><div className="mt-8 flex gap-3"><Button className="rounded-none" onClick={() => answerLab(true)}>Yes</Button><Button variant="outline" className="rounded-none" onClick={() => answerLab(false)}>Not always</Button></div></div>
                ) : (
                  <div className="mt-12 border-l-2 border-[#b9ffde] pl-5"><p className="micro-label">Reflection</p><p className="mt-3 text-xl leading-8 text-white/75">{labScore >= 2 ? "Your choices suggest an active effort to move beyond prediction. The system still influences the field—but it does not fully choose your direction." : "Your answers show how quietly recommendation becomes environment. Influence is not failure; noticing it creates room for another choice."}</p><button onClick={() => { setLabStep(0); setLabScore(0); }} className="mt-6 text-sm text-[#b9ffde] underline underline-offset-4">Run again</button></div>
                )}
              </div>
              <div className="space-y-4">
                {["The Digital Mirror", "Upload", "Data Shadow"].map((title, index) => <div key={title} className="signal-card p-6"><span className="font-mono text-xs text-[#b9ffde]">EXP_00{index + 2}</span><h3 className="mt-8 text-2xl">{title}</h3><p className="mt-2 text-sm leading-6 text-white/45">Prototype queued for a future transmission.</p></div>)}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      <Dialog open={Boolean(selected)} onOpenChange={(open) => !open && setSelected(null)}>
        <DialogContent className="max-h-[92vh] max-w-4xl overflow-y-auto rounded-none border-white/20 bg-[#0b0d0d] p-0">
          {selected && <><DialogHeader className="border-b border-white/15 p-6 pr-14 text-left sm:p-10"><p className="font-mono text-xs tracking-[.16em] text-[#b9ffde]">DATA STREAM / {selected.streamId}</p><DialogTitle className="display-title mt-5 text-4xl font-normal leading-none sm:text-6xl">{selected.title}</DialogTitle><DialogDescription className="mt-4 text-base leading-7 text-white/55">{selected.subtitle}</DialogDescription><div className="mt-4 flex flex-wrap gap-2">{selected.concepts.map((concept) => <span key={concept} className="border border-white/15 px-2 py-1 font-mono text-[.68rem] uppercase tracking-wider text-white/45">{concept}</span>)}</div></DialogHeader><article className="article-prose p-6 sm:p-10">{selected.body.split(/\n\n+/).map((paragraph) => <p key={paragraph}>{paragraph}</p>)}<div className="mt-10 flex items-center justify-between border-t border-white/15 pt-6"><span className="micro-label">End transmission</span><BookOpen className="size-4 text-[#b9ffde]" /></div></article></>}
        </DialogContent>
      </Dialog>
    </main>
  );
}
