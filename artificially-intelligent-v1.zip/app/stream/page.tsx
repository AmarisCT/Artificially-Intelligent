import type { Metadata } from "next";
import { listPublishedArticles } from "@/lib/articles";
import { DataStream } from "./data-stream";

export const metadata: Metadata = {
  title: "The Data Stream",
  description: "Explore transmissions, concepts, connections, and experiments from the Artificially Intelligent archive.",
};

export const dynamic = "force-dynamic";

export default async function StreamPage() {
  const articles = await listPublishedArticles();
  return <DataStream articles={articles} />;
}
