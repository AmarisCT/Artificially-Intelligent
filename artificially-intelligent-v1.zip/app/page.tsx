import Link from "next/link";
import { ArrowUpRight, Asterisk, LockKeyhole } from "lucide-react";

export default function Home() {
  return (
    <main className="landing-shell min-h-screen overflow-hidden px-5 py-5 sm:px-8 sm:py-8">
      <div className="landing-grid" aria-hidden="true" />
      <header className="relative z-10 flex items-center justify-between border-b border-white/15 pb-4 text-[0.72rem] uppercase tracking-[0.2em] text-white/55">
        <span>AI / Editorial system</span>
        <span className="flex items-center gap-2"><i className="status-dot" /> Data stream online</span>
      </header>

      <section className="relative z-10 mx-auto flex min-h-[calc(100vh-84px)] max-w-[1500px] flex-col justify-center py-16">
        <div className="mb-9 flex items-center gap-3 text-xs uppercase tracking-[0.28em] text-[#b9ffde]">
          <Asterisk className="size-4" /> Independent research archive
        </div>
        <h1 className="display-title max-w-6xl text-[clamp(4rem,12vw,10.5rem)] font-medium uppercase leading-[0.76] tracking-[-0.07em] text-[#f2f0e9]">
          Artificially<br />Intelligent
        </h1>

        <div className="mt-10 grid items-end gap-10 border-t border-white/15 pt-6 lg:grid-cols-[1fr_1.2fr]">
          <div>
            <p className="text-sm uppercase tracking-[0.24em] text-white/45">Human × Machine Learning</p>
            <p className="mt-4 max-w-xl text-base leading-7 text-white/68 sm:text-lg">
              An evolving system of essays, concepts, and experiments about identity,
              consciousness, memory, algorithms, and the human machine.
            </p>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <Link href="/stream" className="entry-card group">
              <span className="entry-number">01</span>
              <span>
                <strong>Visitor</strong>
                <small>Enter the Data Stream</small>
              </span>
              <ArrowUpRight className="size-5 transition-transform group-hover:-translate-y-1 group-hover:translate-x-1" />
            </Link>
            <Link href="/architect" className="entry-card group">
              <span className="entry-number">02</span>
              <span>
                <strong>Architect</strong>
                <small>Control the archive</small>
              </span>
              <LockKeyhole className="size-4 text-white/50 transition-colors group-hover:text-[#b9ffde]" />
            </Link>
          </div>
        </div>
      </section>

      <footer className="relative z-10 flex items-center justify-between border-t border-white/15 pt-4 text-[0.68rem] uppercase tracking-[0.18em] text-white/35">
        <span>Built by Jasleen</span>
        <span>Est. 2026 / v1.0</span>
      </footer>
    </main>
  );
}
