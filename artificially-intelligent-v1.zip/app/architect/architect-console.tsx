"use client";

import { FormEvent, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { ArrowLeft, ExternalLink, FilePenLine, Plus, Radio, Trash2 } from "lucide-react";
import type { Article, ArticleInput } from "@/lib/article-types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const emptyInput = (streamId: string): ArticleInput => ({
  streamId,
  slug: "",
  title: "",
  subtitle: "",
  excerpt: "",
  body: "",
  category: "Essay",
  concepts: [],
  status: "draft",
  featured: false,
});

function articleInput(article: Article): ArticleInput {
  return {
    streamId: article.streamId,
    slug: article.slug,
    title: article.title,
    subtitle: article.subtitle,
    excerpt: article.excerpt,
    body: article.body,
    category: article.category,
    concepts: article.concepts,
    status: article.status,
    featured: article.featured,
  };
}

function slugify(value: string) {
  return value.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

export function ArchitectConsole({ articles, displayName, storageAvailable }: { articles: Article[]; displayName: string; storageAvailable: boolean }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Article | null>(null);
  const [deleting, setDeleting] = useState<Article | null>(null);
  const [saving, setSaving] = useState(false);
  const [draft, setDraft] = useState<ArticleInput>(emptyInput("DS_001"));
  const [conceptText, setConceptText] = useState("");

  const nextStreamId = useMemo(() => {
    const highest = articles.reduce((max, article) => {
      const value = Number(article.streamId.match(/\d+/)?.[0] ?? 0);
      return Math.max(max, value);
    }, 0);
    return `DS_${String(highest + 1).padStart(3, "0")}`;
  }, [articles]);

  const published = articles.filter((article) => article.status === "published").length;
  const drafts = articles.length - published;
  const uniqueConcepts = new Set(articles.flatMap((article) => article.concepts)).size;

  function beginNew() {
    setEditing(null);
    setDraft(emptyInput(nextStreamId));
    setConceptText("");
    setOpen(true);
  }

  function beginEdit(article: Article) {
    setEditing(article);
    setDraft(articleInput(article));
    setConceptText(article.concepts.join(", "));
    setOpen(true);
  }

  function setField<K extends keyof ArticleInput>(key: K, value: ArticleInput[K]) {
    setDraft((current) => ({ ...current, [key]: value }));
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    setSaving(true);
    const payload = {
      ...draft,
      slug: draft.slug || slugify(draft.title),
      concepts: conceptText.split(",").map((item) => item.trim()).filter(Boolean),
    };
    try {
      const response = await fetch(editing ? `/api/architect/articles/${editing.id}` : "/api/architect/articles", {
        method: editing ? "PATCH" : "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload),
      });
      const result = await response.json() as { error?: string };
      if (!response.ok) throw new Error(result.error || "Save failed.");
      toast.success(editing ? "Transmission updated." : "Transmission created.");
      setOpen(false);
      router.refresh();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Save failed.");
    } finally {
      setSaving(false);
    }
  }

  async function confirmDelete() {
    if (!deleting) return;
    try {
      const response = await fetch(`/api/architect/articles/${deleting.id}`, { method: "DELETE" });
      const result = await response.json() as { error?: string };
      if (!response.ok) throw new Error(result.error || "Delete failed.");
      toast.success("Transmission deleted.");
      setDeleting(null);
      router.refresh();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Delete failed.");
    }
  }

  return (
    <main className="system-shell min-h-screen">
      <header className="border-b border-white/15 px-4 sm:px-7">
        <div className="mx-auto flex min-h-16 max-w-[1600px] items-center gap-4 py-3">
          <Link href="/" aria-label="Return home" className="grid size-9 place-items-center border border-white/15 text-white/55"><ArrowLeft className="size-4" /></Link>
          <div className="flex-1"><p className="text-sm font-semibold uppercase tracking-[.18em]">Architect Console</p><p className="micro-label mt-0.5">Authenticated as {displayName}</p></div>
          <Button asChild variant="outline" className="hidden rounded-none border-white/20 bg-transparent sm:inline-flex"><Link href="/stream"><ExternalLink /> View live stream</Link></Button>
        </div>
      </header>

      <div className="mx-auto max-w-[1600px] px-4 py-7 sm:px-7">
        <div className="flex flex-col justify-between gap-5 border-b border-white/15 pb-7 sm:flex-row sm:items-end">
          <div><p className="micro-label">System control</p><h1 className="display-title mt-2 text-5xl leading-none sm:text-7xl">Build the archive.</h1></div>
          <Button onClick={beginNew} disabled={!storageAvailable} className="h-11 rounded-none px-5"><Plus /> New transmission</Button>
        </div>

        {!storageAvailable && <div className="mt-6 border border-[#ff817b66] bg-[#ff817b0b] px-5 py-4 text-sm text-white/70">The database is unavailable in this environment. Apply the included migration before creating transmissions.</div>}

        <section className="my-7 grid gap-px border border-white/15 bg-white/15 sm:grid-cols-2 lg:grid-cols-4">
          {[["Published", published], ["Drafts", drafts], ["Concepts", uniqueConcepts], ["System", storageAvailable ? "Online" : "Offline"]].map(([label, value]) => (
            <div key={String(label)} className="bg-[#0d1010] px-5 py-5"><p className="micro-label">{label}</p><p className="mt-3 font-mono text-2xl text-[#b9ffde]">{String(value).padStart(typeof value === "number" ? 2 : 0, "0")}</p></div>
          ))}
        </section>

        <section className="system-panel overflow-hidden">
          <div className="flex items-center justify-between border-b border-white/15 px-5 py-4"><div><p className="micro-label">Transmission registry</p><p className="mt-1 text-sm text-white/45">Saved articles appear across Stream, Map, Index, and Archive automatically.</p></div><Radio className="size-4 text-[#b9ffde]" /></div>
          {articles.length === 0 ? (
            <div className="grid min-h-72 place-items-center p-8 text-center"><div><p className="display-title text-3xl">No saved transmissions yet.</p><p className="mx-auto mt-3 max-w-md text-sm leading-6 text-white/45">The visitor view currently uses the included editorial samples. Create your first transmission to begin replacing the sample archive with your own database.</p><Button className="mt-6 rounded-none" onClick={beginNew} disabled={!storageAvailable}><Plus /> Create transmission</Button></div></div>
          ) : (
            <div className="divide-y divide-white/10">
              {articles.map((article) => (
                <div key={article.id} className="grid gap-4 px-5 py-5 sm:grid-cols-[7rem_1fr_auto] sm:items-center">
                  <div><p className="font-mono text-xs text-[#b9ffde]">{article.streamId}</p><span className={`mt-2 inline-block border px-2 py-1 font-mono text-[.65rem] uppercase ${article.status === "published" ? "border-[#b9ffde55] text-[#b9ffde]" : "border-white/15 text-white/40"}`}>{article.status}</span></div>
                  <div><h2 className="text-lg font-medium">{article.title}</h2><p className="mt-1 text-sm text-white/40">{article.category} · {article.concepts.join(" / ") || "No concepts"}</p></div>
                  <div className="flex gap-2"><Button variant="outline" size="icon" className="rounded-none border-white/20" aria-label={`Edit ${article.title}`} onClick={() => beginEdit(article)}><FilePenLine /></Button><Button variant="outline" size="icon" className="rounded-none border-white/20 text-[#ff817b]" aria-label={`Delete ${article.title}`} onClick={() => setDeleting(article)}><Trash2 /></Button></div>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[94vh] max-w-5xl overflow-y-auto rounded-none border-white/20 bg-[#0b0e0d] p-0">
          <DialogHeader className="border-b border-white/15 p-6 text-left sm:p-8"><p className="micro-label">{editing ? `Edit / ${editing.streamId}` : "New transmission"}</p><DialogTitle className="display-title mt-2 text-4xl font-normal">{editing ? "Revise the signal." : "Publish a new signal."}</DialogTitle><DialogDescription>One record powers every public archive view.</DialogDescription></DialogHeader>
          <form onSubmit={submit} className="grid gap-5 p-6 sm:grid-cols-2 sm:p-8">
            <Field label="Title" className="sm:col-span-2"><Input required value={draft.title} onChange={(e) => { setField("title", e.target.value); if (!editing && !draft.slug) setField("slug", slugify(e.target.value)); }} className="rounded-none" /></Field>
            <Field label="Subtitle" className="sm:col-span-2"><Input value={draft.subtitle} onChange={(e) => setField("subtitle", e.target.value)} className="rounded-none" /></Field>
            <Field label="Stream ID"><Input required value={draft.streamId} onChange={(e) => setField("streamId", e.target.value.toUpperCase())} className="rounded-none font-mono" /></Field>
            <Field label="URL slug"><Input required value={draft.slug} onChange={(e) => setField("slug", slugify(e.target.value))} className="rounded-none font-mono" /></Field>
            <Field label="Category"><Input required value={draft.category} onChange={(e) => setField("category", e.target.value)} className="rounded-none" /></Field>
            <Field label="Concepts" hint="Comma-separated"><Input value={conceptText} onChange={(e) => setConceptText(e.target.value)} placeholder="Identity, Memory, Algorithm" className="rounded-none" /></Field>
            <Field label="Excerpt" hint="10–600 characters" className="sm:col-span-2"><Textarea required value={draft.excerpt} onChange={(e) => setField("excerpt", e.target.value)} className="min-h-28 rounded-none" /></Field>
            <Field label="Article body" hint="Blank lines create paragraphs" className="sm:col-span-2"><Textarea required value={draft.body} onChange={(e) => setField("body", e.target.value)} className="min-h-72 rounded-none font-serif text-base leading-7" /></Field>
            <div className="flex items-center justify-between border border-white/15 px-4 py-3"><div><p className="text-sm font-medium">Published</p><p className="mt-1 text-xs text-white/40">Visible to visitors immediately</p></div><Switch checked={draft.status === "published"} onCheckedChange={(checked) => setField("status", checked ? "published" : "draft")} /></div>
            <div className="flex items-center justify-between border border-white/15 px-4 py-3"><div><p className="text-sm font-medium">Featured</p><p className="mt-1 text-xs text-white/40">Prioritize in the Stream</p></div><Switch checked={draft.featured} onCheckedChange={(checked) => setField("featured", checked)} /></div>
            <div className="flex justify-end gap-3 border-t border-white/15 pt-5 sm:col-span-2"><Button type="button" variant="outline" className="rounded-none" onClick={() => setOpen(false)}>Cancel</Button><Button disabled={saving} className="rounded-none">{saving ? "Saving…" : editing ? "Save revision" : "Create transmission"}</Button></div>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={Boolean(deleting)} onOpenChange={(open) => !open && setDeleting(null)}>
        <AlertDialogContent className="rounded-none border-white/20 bg-[#0b0e0d]"><AlertDialogHeader><AlertDialogTitle>Delete this transmission?</AlertDialogTitle><AlertDialogDescription>{deleting?.title} will be permanently removed from the Data Stream.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel className="rounded-none">Cancel</AlertDialogCancel><AlertDialogAction variant="destructive" className="rounded-none" onClick={confirmDelete}>Delete</AlertDialogAction></AlertDialogFooter></AlertDialogContent>
      </AlertDialog>
    </main>
  );
}

function Field({ label, hint, className = "", children }: { label: string; hint?: string; className?: string; children: React.ReactNode }) {
  return <label className={`grid gap-2 ${className}`}><span className="flex items-center justify-between text-sm"><strong className="font-medium">{label}</strong>{hint && <small className="text-white/35">{hint}</small>}</span>{children}</label>;
}
