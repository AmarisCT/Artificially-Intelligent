import Link from "next/link";
import { ArrowLeft, LockKeyhole, ShieldAlert } from "lucide-react";
import { chatGPTSignInPath } from "@/app/chatgpt-auth";
import { getArchitectAccess } from "@/lib/architect";
import { listAllArticles } from "@/lib/articles";
import type { Article } from "@/lib/article-types";
import { ArchitectConsole } from "./architect-console";

export const dynamic = "force-dynamic";

export default async function ArchitectPage() {
  const access = await getArchitectAccess();

  if (!access.user) {
    return <Gate title="Architect access" message="Sign in with ChatGPT to authenticate before entering the console." action={<a href={chatGPTSignInPath("/architect")} target="_top" className="inline-flex h-11 items-center justify-center bg-[#b9ffde] px-5 text-sm font-semibold text-[#07110d]">Authenticate with ChatGPT</a>} />;
  }

  if (!access.configured) {
    return <Gate title="One secure setting remains" message={`You are signed in as ${access.user.email}. Set ARCHITECT_EMAIL to this address in the deployment environment, then reload. No password is stored in the code.`} icon={<LockKeyhole className="size-6 text-[#b9ffde]" />} />;
  }

  if (!access.authorized) {
    return <Gate title="Access denied" message={`${access.user.email} is authenticated, but it is not the configured Architect account.`} icon={<ShieldAlert className="size-6 text-[#ff817b]" />} />;
  }

  let articles: Article[] = [];
  let storageAvailable = true;
  try {
    articles = await listAllArticles();
  } catch {
    storageAvailable = false;
  }
  return <ArchitectConsole articles={articles} displayName={access.user.displayName} storageAvailable={storageAvailable} />;
}

function Gate({ title, message, action, icon }: { title: string; message: string; action?: React.ReactNode; icon?: React.ReactNode }) {
  return (
    <main className="landing-shell grid min-h-screen place-items-center p-5">
      <div className="landing-grid" aria-hidden="true" />
      <section className="relative z-10 w-full max-w-xl border border-white/20 bg-[#0c0f0ff2] p-7 sm:p-10">
        <div className="mb-12 flex items-center justify-between"><span className="micro-label">Architect / Restricted</span>{icon ?? <LockKeyhole className="size-6 text-[#b9ffde]" />}</div>
        <h1 className="display-title text-5xl leading-none">{title}</h1>
        <p className="mt-5 leading-7 text-white/60">{message}</p>
        <div className="mt-8 flex flex-wrap gap-3">{action}<Link href="/" className="inline-flex h-11 items-center justify-center gap-2 border border-white/20 px-5 text-sm"><ArrowLeft className="size-4" /> Return</Link></div>
      </section>
    </main>
  );
}
