import { env } from "cloudflare:workers";
import { getChatGPTUser } from "@/app/chatgpt-auth";

export async function getArchitectAccess() {
  const user = await getChatGPTUser();
  const configuredEmail = env.ARCHITECT_EMAIL?.trim().toLowerCase() ?? "";
  return {
    user,
    configured: Boolean(configuredEmail),
    authorized: Boolean(user && configuredEmail && user.email.toLowerCase() === configuredEmail),
  };
}

export async function requireArchitectApi() {
  const access = await getArchitectAccess();
  if (!access.user) return { ok: false as const, status: 401, message: "Sign in is required." };
  if (!access.configured) return { ok: false as const, status: 503, message: "Architect access is not configured." };
  if (!access.authorized) return { ok: false as const, status: 403, message: "This account does not have Architect access." };
  return { ok: true as const, user: access.user };
}
