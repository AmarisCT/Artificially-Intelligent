import { env } from "cloudflare:workers";
import type { Article, ArticleInput } from "./article-types";
import { sampleArticles } from "./sample-articles";

type ArticleRow = {
  id: string;
  stream_id: string;
  slug: string;
  title: string;
  subtitle: string;
  excerpt: string;
  body: string;
  category: string;
  concepts: string;
  status: "draft" | "published";
  featured: number;
  published_at: string | null;
  created_at: string;
  updated_at: string;
};

const SELECT_COLUMNS = `
  id, stream_id, slug, title, subtitle, excerpt, body, category,
  concepts, status, featured, published_at, created_at, updated_at
`;

function database() {
  if (!env.DB) throw new Error("The article database is not available.");
  return env.DB;
}

function rowToArticle(row: ArticleRow): Article {
  let concepts: string[] = [];
  try {
    const parsed = JSON.parse(row.concepts);
    if (Array.isArray(parsed)) concepts = parsed.filter((item) => typeof item === "string");
  } catch {
    concepts = [];
  }
  return {
    id: row.id,
    streamId: row.stream_id,
    slug: row.slug,
    title: row.title,
    subtitle: row.subtitle,
    excerpt: row.excerpt,
    body: row.body,
    category: row.category,
    concepts,
    status: row.status,
    featured: Boolean(row.featured),
    publishedAt: row.published_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export async function listPublishedArticles(): Promise<Article[]> {
  try {
    const result = await database()
      .prepare(`SELECT ${SELECT_COLUMNS} FROM articles WHERE status = ? ORDER BY published_at DESC, created_at DESC`)
      .bind("published")
      .all<ArticleRow>();
    const saved = result.results.map(rowToArticle);
    return saved.length ? saved : sampleArticles;
  } catch {
    return sampleArticles;
  }
}

export async function listAllArticles(): Promise<Article[]> {
  const result = await database()
    .prepare(`SELECT ${SELECT_COLUMNS} FROM articles ORDER BY updated_at DESC`)
    .all<ArticleRow>();
  return result.results.map(rowToArticle);
}

export async function createArticle(input: ArticleInput): Promise<Article> {
  const id = crypto.randomUUID();
  const now = new Date().toISOString();
  const publishedAt = input.status === "published" ? now : null;
  await database()
    .prepare(`INSERT INTO articles (
      id, stream_id, slug, title, subtitle, excerpt, body, category,
      concepts, status, featured, published_at, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .bind(
      id,
      input.streamId,
      input.slug,
      input.title,
      input.subtitle,
      input.excerpt,
      input.body,
      input.category,
      JSON.stringify(input.concepts),
      input.status,
      input.featured ? 1 : 0,
      publishedAt,
      now,
      now,
    )
    .run();
  return { id, ...input, publishedAt, createdAt: now, updatedAt: now };
}

export async function updateArticle(id: string, input: ArticleInput): Promise<void> {
  const now = new Date().toISOString();
  const current = await database()
    .prepare("SELECT published_at FROM articles WHERE id = ?")
    .bind(id)
    .first<{ published_at: string | null }>();
  const publishedAt =
    input.status === "published" ? current?.published_at ?? now : null;
  await database()
    .prepare(`UPDATE articles SET
      stream_id = ?, slug = ?, title = ?, subtitle = ?, excerpt = ?, body = ?,
      category = ?, concepts = ?, status = ?, featured = ?, published_at = ?, updated_at = ?
      WHERE id = ?`)
    .bind(
      input.streamId,
      input.slug,
      input.title,
      input.subtitle,
      input.excerpt,
      input.body,
      input.category,
      JSON.stringify(input.concepts),
      input.status,
      input.featured ? 1 : 0,
      publishedAt,
      now,
      id,
    )
    .run();
}

export async function deleteArticle(id: string): Promise<void> {
  await database().prepare("DELETE FROM articles WHERE id = ?").bind(id).run();
}
