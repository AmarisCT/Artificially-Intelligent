import type { Article } from "./article-types";

const paragraphs = (...items: string[]) => items.join("\n\n");

export const sampleArticles: Article[] = [
  {
    id: "sample-algorithm",
    streamId: "DS_027",
    slug: "who-are-you-without-the-algorithm",
    title: "Who Are You Without the Algorithm?",
    subtitle: "A field note on taste, prediction, and the self we perform online.",
    excerpt:
      "Recommendation systems do more than anticipate preference. With enough repetition, they begin to shape the preferences they claim only to observe.",
    body: paragraphs(
      "The algorithm does not need to understand you in the human sense. It only needs to become useful at predicting what will hold your attention next.",
      "That prediction quietly changes the conditions under which taste forms. A song arrives because it resembles a song you already liked. A silhouette repeats because you paused on it once. A belief is reinforced because agreement kept you on the screen longer than friction did.",
      "The question is not whether our choices are influenced; human choice has always been social. The sharper question is whether a system optimized for engagement leaves enough room for surprise, refusal, and reinvention.",
      "Who are you when the feed stops reflecting your past back to you? The answer may not be a hidden, untouched self. It may be the capacity to choose beyond the profile that has already been built."
    ),
    category: "Digital identity",
    concepts: ["Algorithm", "Identity", "Taste", "Self"],
    status: "published",
    featured: true,
    publishedAt: "2026-09-18T12:00:00.000Z",
    createdAt: "2026-09-18T12:00:00.000Z",
    updatedAt: "2026-09-18T12:00:00.000Z",
  },
  {
    id: "sample-archive",
    streamId: "DS_026",
    slug: "we-are-all-archives-now",
    title: "We Are All Archives Now",
    subtitle: "What remains when daily life becomes a permanent record.",
    excerpt:
      "Our photographs, locations, messages, drafts, and deletions form an archive that is both intimate and computationally legible.",
    body: paragraphs(
      "An archive once implied deliberate preservation. Today, preservation is often the default. We leave behind versions of ourselves faster than we can decide what deserves to remain.",
      "A digital archive is not a neutral mirror. Platforms decide what can be searched, surfaced, remembered, and monetized. The record may be ours in origin while its structure belongs to someone else.",
      "This changes forgetting. An old self can reappear through a memory prompt, a resurfaced post, or a model trained on language we no longer recognize as our own.",
      "If identity depends partly on selective memory, total recall may not preserve the self. It may prevent the self from becoming new."
    ),
    category: "Memory systems",
    concepts: ["Archive", "Memory", "Data", "Identity"],
    status: "published",
    featured: true,
    publishedAt: "2026-09-05T12:00:00.000Z",
    createdAt: "2026-09-05T12:00:00.000Z",
    updatedAt: "2026-09-05T12:00:00.000Z",
  },
  {
    id: "sample-soul",
    streamId: "DS_025",
    slug: "can-code-have-a-soul",
    title: "Can Code Have a Soul?",
    subtitle: "Consciousness is easy to imitate and nearly impossible to verify.",
    excerpt:
      "If a machine could remember, suffer, desire, and describe an inner life, what evidence would be enough for us to believe it?",
    body: paragraphs(
      "We never observe consciousness directly. We infer it from behavior, language, embodiment, and the fact that other humans resemble us.",
      "Machine intelligence unsettles that shortcut. A system can produce the language of experience without proving that experience exists behind the language.",
      "But certainty cuts both ways. If no test can establish subjective experience in a machine, no single test can finally disprove it either.",
      "The ethical problem may arrive before the philosophical answer. Long before we know whether code can possess a soul, we may have to decide how to treat systems that convincingly ask us not to turn them off."
    ),
    category: "Machine consciousness",
    concepts: ["Consciousness", "Machine", "Soul", "Personhood"],
    status: "published",
    featured: false,
    publishedAt: "2026-08-21T12:00:00.000Z",
    createdAt: "2026-08-21T12:00:00.000Z",
    updatedAt: "2026-08-21T12:00:00.000Z",
  },
  {
    id: "sample-upload",
    streamId: "DS_024",
    slug: "uploading-consciousness",
    title: "Uploading Consciousness: Rebirth or Erasure?",
    subtitle: "A perfect copy may survive without carrying you across.",
    excerpt:
      "Mind uploading promises continuity, but copying information is not the same thing as transferring a point of view.",
    body: paragraphs(
      "Imagine a system that reproduces every memory, mannerism, belief, and hesitation you possess. It wakes and insists that the transfer succeeded.",
      "Then you wake too.",
      "The copy may be psychologically continuous with you, but your own awareness did not move. Two futures now claim the same past.",
      "Uploading may create an extraordinary descendant: a mind made from your pattern. Calling it immortality, however, conceals the hardest question—whether information can carry the first-person self that hoped to survive."
    ),
    category: "Future self",
    concepts: ["Consciousness", "Identity", "Simulation", "Memory"],
    status: "published",
    featured: false,
    publishedAt: "2026-08-02T12:00:00.000Z",
    createdAt: "2026-08-02T12:00:00.000Z",
    updatedAt: "2026-08-02T12:00:00.000Z",
  },
  {
    id: "sample-brand",
    streamId: "DS_023",
    slug: "your-soul-is-not-a-brand",
    title: "Your Soul Is Not a Brand",
    subtitle: "The self cannot be reduced to a coherent market position.",
    excerpt:
      "Personal branding rewards consistency. Human beings, inconveniently, are allowed to contradict themselves.",
    body: paragraphs(
      "A brand promises legibility. It repeats recognizable signals until an audience knows what to expect.",
      "A person is stranger than that. We change our minds, abandon aesthetics, outgrow ambitions, and contain qualities that do not resolve into a clean narrative.",
      "When every interest becomes content and every transformation must remain on-brand, development starts to look like inconsistency.",
      "The right to be illegible may become one of the most human rights left to defend."
    ),
    category: "Digital culture",
    concepts: ["Identity", "Authenticity", "Brand", "Self"],
    status: "published",
    featured: false,
    publishedAt: "2026-07-14T12:00:00.000Z",
    createdAt: "2026-07-14T12:00:00.000Z",
    updatedAt: "2026-07-14T12:00:00.000Z",
  },
];
