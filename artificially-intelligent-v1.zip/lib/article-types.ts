export type ArticleStatus = "draft" | "published";

export type Article = {
  id: string;
  streamId: string;
  slug: string;
  title: string;
  subtitle: string;
  excerpt: string;
  body: string;
  category: string;
  concepts: string[];
  status: ArticleStatus;
  featured: boolean;
  publishedAt: string | null;
  createdAt: string;
  updatedAt: string;
};

export type ArticleInput = Pick<
  Article,
  | "streamId"
  | "slug"
  | "title"
  | "subtitle"
  | "excerpt"
  | "body"
  | "category"
  | "concepts"
  | "status"
  | "featured"
>;
