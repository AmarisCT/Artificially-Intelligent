# Artificially Intelligent — Human × ML

An interactive editorial research environment for essays and experiments about artificial intelligence, identity, consciousness, memory, algorithms, digital culture, and the human–machine boundary.

This first release combines the public **Data Stream** with a private **Architect Console**. One article record automatically appears across the Stream, Map, Index, and Archive.

## Included in v1

- Editorial entry screen with separate Visitor and Architect paths
- Searchable Data Stream with full article reading dialogs
- Automatically generated concept map and index
- Chronological archive view
- Interactive Lab prototype: *Who Are You Without the Algorithm?*
- Secure ChatGPT authentication for the Architect route
- Server-side Architect email allowlist
- Create, revise, publish, unpublish, feature, and delete transmissions
- Durable Cloudflare D1 article storage
- Responsive layout and keyboard-accessible interface primitives
- Five starter essays displayed until the database contains a published article

## Stack

- Next.js-compatible Vinext application
- React 19 + TypeScript
- Tailwind CSS 4
- Radix/Shadcn interface primitives
- Cloudflare Workers + D1
- Drizzle schema and migrations
- ChatGPT sign-in supplied by the hosting platform

## Run locally

Requirements: Node.js 22.13+ and pnpm 11.

```bash
pnpm install
cp .env.example .env.local
pnpm db:generate
pnpm build
pnpm dev
```

Set `ARCHITECT_EMAIL` in `.env.local` to the email on the ChatGPT account that should control publishing.

The hosted platform supplies authentication headers. The included development environment can simulate sign-in where supported; see the starter runtime documentation for the local sign-in route.

## Database

The D1 binding is named `DB`. The schema lives in `db/schema.ts`, and generated SQL migrations live in `drizzle/`.

The public archive falls back to `lib/sample-articles.ts` only when no published database records are available. Once you publish your first saved transmission, the database becomes the public source of truth.

## Security

The Architect console does not use a password embedded in JavaScript. Publishing access requires both:

1. a valid ChatGPT-authenticated session; and
2. an email matching the server-side `ARCHITECT_EMAIL` environment variable.

Never commit `.env.local`, hosting credentials, or access keys. If a short password was previously considered for this project, do not reuse it.

## Project map

```text
app/
  page.tsx                         Entry screen
  stream/                          Public Data Stream
  architect/                       Protected publishing console
  api/architect/articles/          Protected article API
db/
  schema.ts                        Article database schema
lib/
  articles.ts                      D1 queries and mutations
  architect.ts                     Authorization checks
  sample-articles.ts               Editorial starter content
public/
  favicon.svg                      Brand mark
```

## Customize

- Replace starter essays in `lib/sample-articles.ts`.
- Adjust the visual system in `app/globals.css`.
- Change landing copy in `app/page.tsx`.
- Add new experiments inside `app/stream/data-stream.tsx`.

## License

MIT
